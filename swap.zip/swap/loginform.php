<html>
<head>
	<title>TP AMC - Login</title>
    <head>
	<meta charset="utf-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    	<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/basic.css">
	</head>
	<?php 
		session_start(); 
		require "/xampp/htdocs/swap/head&foot/header(login).php";
		$_SESSION['token'] =md5(uniqid(mt_rand(),true)); //create token and store in SESSION
		$_SESSION['token_time'] = time();
	?>
	<?php

		if(isset($_SESSION['attempt_again'])){
			$now = time();
			if($now >= $_SESSION['attempt_again']){
				unset($_SESSION['attempt']);
				unset($_SESSION['attempt_again']);
			}
		}
	 
		//set disable if three login attempts has been made
		$disable = '';
		if(isset($_SESSION['attempt']) && $_SESSION['attempt'] >= 3){
			$disable = 'disabled';
		}
	?>
	<?php if (isset($_SESSION['message'])): ?>    
		<div class="alert alert-<?= $_SESSION['msg_type']?>">
			<?php 
				echo $_SESSION['message'];
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>
	<?php require "logindo.php"?>
</head>
<body>
<div class="signup-form">
		<form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
			<input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?>">
            <h2>Enter your credentials</h2>
            <p class="hint-text">Strictly accessible by members of TP-AMC only</p>

            <div class="form-group">
                <input type="text" class="form-control" name="nric" placeholder="NRIC" autocomplete="off" <?php echo $disable; ?>>
            </div>
			<div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password" <?php echo $disable; ?>>
            </div>
            
            <div class="form-group">
                <button class="btn btn-success btn-lg btn-block" name="login" <?php echo $disable; ?>>Login</button>
            </div>
		</form>
	</div>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>