<?php 
    session_start();
    session_regenerate_id();
    if($_SESSION['admin'] == "Yes"):
    require_once "/xampp/htdocs/swap/main/main_process.php";
?>

<html lang="en">
    <?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<head>
    <title>TP AMC - Maintenance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
<a href="main_index.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<form action ="main_edit.php" method="POST">
        <div class="signup-form">
            <input type="hidden" name="eid" value="<?php echo urlencode(base64_encode($editid)) ?> ">
            <h2>Edit Maintenance Schedule</h2>
            <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>
            <input type="hidden" name="UserId" disabled class="form-control" style="position: relative; left: 30px; height: 50px; font-size: 20px" value="<?php echo $UserId; ?>">

            <div class="form-group">
                <input type="text" disabled class="form-control" id="fullname" name="fullname" value="<?php echo $FullName; ?>">
            </div>

            <div class="form-group">
                <input type="text" disabled class="form-control" id="sector" name="sector" value="<?php echo $Sector; ?>">	
            </div>
                
            <div class="form-group">
                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required="true" value="<?php echo $Subject;?>">
            </div>
                
            <div class="form-group">
                <textarea class="form-control" id="body" name="body" placeholder="Enter Maintenance Schedule Information" required="true" value=""><?php echo $Body;?></textarea>
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="update">Submit</button>
            </div>
        </div>
    </form>
<body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
<html>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: home(user).php")?>
<?php else:?>
    <?php header("location: loginform.php")?>
<?php endif; ?>