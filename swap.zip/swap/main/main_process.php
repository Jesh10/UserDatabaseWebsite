<?php
    //database conection  file
    $conn = new mysqli('localhost', 'root', '', 'swap');

    function forgery_check(){ //check if form is in the same domain
        if(!isset($_SERVER['HTTP_REFERER'])){
            return false;
        }else{
            $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            $server_host = $_SERVER['HTTP_HOST'];
            return ($referer_host == $server_host) ? true :false ;
        }
    }

    if(forgery_check()){
        if(isset($_POST['submit'])){
            //getting the post values
            $userid=$_SESSION['userid'];
            $fullname=$_SESSION['fullname'];
            $sector=$_SESSION['jobposition'];
            $subject=strip_tags($_POST['subject']);
            $body=strip_tags($_POST['body']);

        // Query for data insertion
        if($subject=="") {
            $_SESSION['message'] = "Provide a Subject";    
            $_SESSION['msg_type'] = "danger";
        } else if($body=="") {
            $_SESSION['message'] = "Body Field cannot be empty";    
            $_SESSION['msg_type'] = "danger";
        }else{
            $sql =$conn->prepare("INSERT INTO maintenance (`UserId`, `FullName`, `Sector`, `Subject`, `Body`) VALUES (?, ?, ?, ?, ?)");
            $sql->bind_param('issss',$userid,$fullname,$sector,$subject,$body);
            if ($sql->execute()) {
                $_SESSION['message'] = "Successfully Created Maintenance Schedule";    
                $_SESSION['msg_type'] = "success";
                echo "<script>window.location.href = 'main_index.php'</script>"; 
            }else{ 
                echo "<script>alert('Unable to upload newly filled maintenance schedule. Please try again');</script>";
                echo mysqli_error($conn)."<br>";
                }
            }
        }

        $eid=0;
        $UserId = 0;
        $FullName = "";
        $DateTime= "";
        $Sector = "";
        $Subject = "";
        $Body = "";

        if (isset($_GET['editid'])){
            $eid = $_GET['editid'];
            $EID = base64_decode(urldecode($eid));
            $result = $conn->prepare("SELECT * FROM maintenance WHERE MaintenanceId=$EID");
            $result->bind_result($editid, $UserId, $FullName, $DateTime, $Sector, $Subject, $Body);
            $result->store_result();
            $result->execute();
            $result->fetch();
        }

        //Code for update
        if(isset($_POST['update']))
        {
            // Retrieving post values
            $eid=$_POST['eid'];
            $editid = base64_decode(urldecode($eid));
            $subject=strip_tags($_POST['subject']);
            $body=strip_tags($_POST['body']);
        
            // Query for data updation
            $sql= $conn->prepare("UPDATE maintenance SET `Subject`=?, `Body`=? WHERE `MaintenanceId`=?");
            $sql->bind_param('ssi', $subject, $body, $editid);

            if ($sql->execute()) {
                $_SESSION['message'] = "Successfully updated the maintenance schedule";
                $_SESSION['msg_type'] = "success";
                header("location: main_index.php");
            }else{
                $_SESSION['message'] = "Invalid Maintenance Schedule";    
                $_SESSION['msg_type'] = "danger";
            }
        }

        //Code for deletion
        if(isset($_GET['delid'])){
            $rid=($_GET['delid']);
            $did = base64_decode(urldecode($rid));
            $query=$conn->prepare("DELETE FROM `maintenance` WHERE `MaintenanceId` = ?");
            $query->bind_param('i', $did);
            if($query->execute()){
                $_SESSION['message'] = "Successfully Deleted Maintenance Schedule";    
                $_SESSION['msg_type'] = "success";
                header("location: main_index.php");
            }else{
                $_SESSION['message'] = "Maintenance Schedule could not be Deleted";    
                $_SESSION['msg_type'] = "danger";
            }  
        } 
    }else{
        exit();
    }
?>