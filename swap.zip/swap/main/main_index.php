<?php session_start();?>
<?php if(!isset($_SESSION['admin'])):?>
    <?php header("location: loginform.php");?>
<?php else: ?>
<?php
    if($_SESSION["admin"] == "Yes"){
        require "/xampp/htdocs/swap/head&foot/header(admin).php";
    }else{
        require "/xampp/htdocs/swap/head&foot/header(user).php";
    }
    require_once "/xampp/htdocs/swap/main/main_process.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>TP AMC - Maintenance</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/default.css"/>
    <link rel="stylesheet" href="/swap/css/footer.css"/>
</head>
<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-<?=$_SESSION['msg_type']?>">
        <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        ?>
    </div>
<?php endif ?>
<body>
    <div class="container-xl">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-6">
                            <h2>Maintenance Schedule for <b><?php echo $_SESSION["jobposition"]?></b></h2>
                        </div>
                    </div>
                </div>
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Created By</th>                       
                            <th>Created At</th>
                            <th>Subject</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $result = $conn->prepare("SELECT * FROM maintenance");
                            $result->bind_result($maintenanceid, $userid, $fullname, $datetime, $sector, $subject, $body);
                            $result->store_result();
                            $res=$result->execute();
                            while ($result->fetch()): 
                        ?>
                        <?php if($sector == $_SESSION["jobposition"]):?>
                            <!--Fetch the Records -->
                        <tr>
                            <td><?php echo $maintenanceid;?></td>
                            <td><?php echo $fullname;?>
                            <td><?php
                                $datetime = new DateTime($datetime); 
                                echo $datetime->format("d-m-Y h:i:s"); ?></td>                        
                            <td><?php echo $subject;?></td>
                            <?php if($_SESSION["admin"] == "Yes"): ?>
                            <td>
                                <a href="main_read.php?viewid=<?php echo urlencode(base64_encode($maintenanceid));?>" class="view" title="View" data-toggle="tooltip"><i class="material-icons">&#xE417;</i></a>
                                <a href="main_edit.php?editid=<?php echo urlencode(base64_encode($maintenanceid));?>" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                                <a href="main_index.php?delid=<?php echo urlencode(base64_encode($maintenanceid));?>" class="delete" title="Delete" data-toggle="tooltip" onclick="return confirm('Confirm to delete?');"><i class="material-icons">&#xE872;</i></a>
                            </td>
                            <?php else: ?>
                            <td>
                                <a href="main_read.php?viewid=<?php echo urlencode(base64_encode($maintenanceid));?>" class="view" title="View" data-toggle="tooltip"><i class="material-icons">&#xE417;</i></a>
                            </td>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endwhile; ?>
                        </tr>                 
                    </tbody>
                </table>
                <?php if($_SESSION["admin"] == "No"):?>
                <?php elseif($_SESSION["admin"] == "Yes"):?>
                    <a href="main_insert.php" type="button" class="btn btn-secondary btn-lg btn-block"><i style="position: relative; top: 5px; right: 5px;" class="material-icons">&#xE147;</i><span>Create New Maintenance Schedule</span></a>
                <?php endif; ?>
            </div>
        </div>
    </div>    
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>
<?php endif; ?>