<?php
    session_start();
?>
<?php if($_SESSION["admin"]==""): ?>
    <?php header("location: loginform.php")?>
<?php else:?>
<?php
    $conn = new mysqli('localhost', 'root', '', 'swap');
    if($_SESSION["admin"] == "Yes"){
        require "/xampp/htdocs/swap/head&foot/header(admin).php";
    }else{
        require "/xampp/htdocs/swap/head&foot/header(user).php";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>TP AMC - Maintenance</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/read.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
    <a href="main_index.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
    <div class="container-xl">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                        <div class="col-sm-5">
                            <h2>Maintenance Schedule Details for <b><?php echo $_SESSION["jobposition"]?></b></h2>
                        </div>
                    </div>
                </div>
    <table cellpadding="0" cellspacing="0" bordered="0" class="display table table-bordered" id="hidden-table-info">
                
    <tbody>
    <?php
        $vid=$_GET['viewid'];
        $VID = base64_decode(urldecode($vid));
        $result = $conn->prepare("SELECT * FROM maintenance where MaintenanceId = $VID");
        $result->bind_result($VID, $userid, $fullname, $datetime, $sector, $subject, $body);
        $result->store_result();
        $res=$result->execute();
        while ($result->fetch()):
    ?>
    <tr>
        <th>S/N</th>
        <td><?php  echo $VID;?></td>
    </tr>
    <tr>
        <th>Full Name</th>
        <td><?php  echo $fullname;?></td>
    </tr>
    <tr>
        <th>Date & Time</th>
        <td><?php
            $datetime = new DateTime($datetime); 
            echo $datetime->format("d-m-Y h:i:s"); ?></td>
    </tr>
    <tr>
        <th>Subject</th>
        <td><?php  echo $subject;?></td>
    </tr>
    <tr>
        <th>Body</th>
        <td><?php  echo $body;?></td>
    </tr>
    <?php endwhile; ?>
    </tbody>
    </table>
            </div>
        </div>
    </div> 
<?php endif; ?>    
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>