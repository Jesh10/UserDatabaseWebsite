<html lang="en">  
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
<footer class="" style="margin-top:70px">
    <div class="footer">
        <p style="margin-top:10px;"> Find out more on 
        <a href="https://www.tp.edu.sg/research-and-industry/centres-of-excellence/centres-under-school-of-engineering/advanced-manufacturing-centre.html" style="color: #444444;">tp.edu.sg </a>
        <a>| Contact us at <a style="color: #444444;" href="mailto:contactamc@tp.edu.sg">contactamc@tp.edu.sg</a> </a> </p>
    </div>
</footer>
</body>
</html>