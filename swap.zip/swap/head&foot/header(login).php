<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="/swap/loginform.php" style="height: 75px;">
        <img src="/swap/images/tplogo.webp" width="60" height="44" class="d-inline-block align-top" alt="" style="margin-top: 10px;">
        <label for = "name" style="position:relative; left:10px; font-size: 40px;">TP AMC</label>
    </a>
</nav>