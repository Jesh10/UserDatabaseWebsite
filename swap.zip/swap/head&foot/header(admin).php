<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="/swap/home(admin).php" style="height: 75px;">
        <img src="/swap/images/tplogo.webp" width="60" height="44" class="d-inline-block align-top" alt="" style="margin-top: 10px;">
        <label for = "name" style="position:relative; left:10px; font-size: 40px;">TP AMC</label>
    </a>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/swap/home(admin).php" style="font-size: 18px;">Dashboard</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="/swap/authen/employees.php" style="font-size: 18px;">Employees</a>
      </li>
      <li class="nav-item active">
        <a onclick="return confirm('Are you sure you want to Logout?')" class="nav-link" name="logout" href="/swap/logout.php" style="font-size: 18px;">Logout</a>
      </li>
    </ul>
  </div>
</nav>