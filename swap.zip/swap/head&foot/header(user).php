<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="/swap/home(user).php" style="height: 75px;">
    <img src="/swap/images/tplogo.webp" width="60px" height="44px" class="d-inline-block align-top" alt="" style="margin-top: 10px;">
        <label for = "name" style="position:relative; left:10px; font-size: 40px;">TP AMC</label>
    </a>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" style="margin-left: 15px;">
            <li class="nav-item">
            </li>
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="/swap/home(user).php" style="font-size: 20px; ">  
                        Dashboard
                </a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="/swap/reports/report.php" style="font-size: 20px; ">  
                        Reports
                </a>
            </li>
            <li class="nav-item active">
                <a onclick="return confirm('Are you sure you want to Logout?');" class="nav-link" href="/swap/logout.php" name="logout" style="font-size: 20px;" type="submit">  
                        Logout
                </a>
            </li>
        </ul>        
    </div>
</nav>