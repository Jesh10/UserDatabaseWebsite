<?php
if(isset($_POST['login'])){
	if (!isset($_POST['token']) && $_POST['token'] !== $_SESSION['token'])  //check if token valid
	{
		// return 405 http status code
		header($_SERVER['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
		exit;
	}else{
		$token_age = time() - $_SESSION['token_time'];
		if ($token_age <= 300)
		{
			logindo($_POST["nric"], $_POST["password"]);
		}else{
			header($_SERVER['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
		}
	}
}
if(!isset($_SESSION['attempt'])){
	$_SESSION['attempt'] = 0;
}

function logindo($nric, $password) {
	try {
		$con = new mysqli('localhost', 'root', '', 'swap');
	}
	catch (Exception $e) {
		printerror($e->getMessage(),$con);
	}
	
	$query = $con->prepare("SELECT * FROM swap.users WHERE NRIC=?");
	$query->bind_param("s", $nric);
	$query->execute();
	$query->store_result();
	$query->bind_result($userid,$registernum,$fullname,$pw,$dob,$gender,$nricnum,$email,$jobposition,$admin,$filename);
	$query->fetch();
	
	if (password_verify($password, $pw)){
		// You should session_start first before inserting into $_SESSION
		unset($_SESSION['attempt']);
		$_SESSION["userid"]=$userid; 
		$_SESSION["registernum"]=$registernum;
		$_SESSION["fullname"]=$fullname; 
		$_SESSION["jobposition"]=$jobposition; 
		$_SESSION["admin"]=$admin; 

		// the path matters when you delete the cookie again, needs to match
		setcookie("colour", "red", time()+30*24*60*60, "/"); 
		setcookie("weather","good", time()+30*24*60*60, "/");
		session_regenerate_id();
	
		mysqli_close($con);

		if($_SESSION["admin"]=="No"){
			header("location: /swap/home(user).php");
			//echo "<pre><a href='home(user).php'>Click to goto Login done</a></pre>";
		}else{
			header("location: /swap/home(admin).php");
		}
	} else{
		$_SESSION['attempt'] += 1;
		//set the time to allow login if third attempt is reach
		if($_SESSION['attempt'] == 3){
			$_SESSION['attempt_again'] = time() + (1*60);
			$_SESSION['message'] = "Login Disabled. Try again in 1 minute.";    
			$_SESSION['msg_type'] = "danger";
		}else{
			$_SESSION['message'] = "Invalid Credentials";    
			$_SESSION['msg_type'] = "danger";
		}
	}
}
?>