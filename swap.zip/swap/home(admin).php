<?php 
    session_start();
    session_regenerate_id();
    
    if($_SESSION['admin'] == "Yes"):
 ?>
<!DOCTYPE html>
<html lang="en">
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
    <head>  
    <title>TP AMC - Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/animate.css">
    <link rel="stylesheet" href="/swap/css/basic.css">
    </head>
    <body>
    <div >        
        <div class="first" style="margin-top: 100px; text-align: center;"> 
            <button type="button" class="btn btn-outline-primary" onclick="window.location.href='/swap/attendance/attendance_list.php'" style="width: 370px; height: 170px; margin-right: 20px">
            <h3>ATTENDANCE</h3>
            <sub>Update Attendance of your employees</sub>
            </button>

            <button type="button" class="btn btn-outline-danger" onclick="window.location.href='/swap/reports/report.php'" style="width: 370px; height: 170px;">
            <h3>REPORT</h3>
            <sub>Review reports of your employees</sub>
            </button>
        </div>

            <br>

        <div class="second" style="margin-bottom: 100px; text-align: center;">
            <button type="button" class="btn btn-outline-warning" onclick="window.location.href='/swap/main/main_index.php'" style="width: 370px; height: 170px; margin-right: 20px">
            <h3>MAINTENANCE SCHEDULE</h3>
            <sub>Record of machinary scheduled for maintenance</sub>
            </button>
            
            <button type="button" class="btn btn-outline-success" onclick="window.location.href='/swap/announcements/announcement.php'" style="width: 370px; height: 170px;">
            <h3>ANNOUNCEMENT</h3>
            <sub>Be notified of the latest updates</sub>
            </button>
        </div>
    </div> 

    <?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
    </body>
    <?php elseif($_SESSION['admin'] == "No"):?>
        <?php header("location: home(user).php")?>
    <?php else:?>
        <?php header("location: loginform.php")?>
    <?php endif; ?>
</html>
