<?php
    session_start();
?>
<?php if($_SESSION["admin"]==""): ?>
    <?php header("location: loginform.php")?>
<?php else:?>
<?php
    $conn = new mysqli('localhost','root','','swap');
    if($_SESSION["admin"] == "Yes"){
        require "/xampp/htdocs/swap/head&foot/header(admin).php";
    }else{
        require "/xampp/htdocs/swap/head&foot/header(user).php";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>TP AMC - Maintenance</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="/swap/css/read.css">
<link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
<a href="report.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-4">
                        <h2>Report <b>Details</b> for <?php echo $_SESSION["jobposition"]?></h2>
                    </div>
                </div>
            </div>
            <table cellpadding="0" cellspacing="0" bordered="0" class="display table table-bordered" id="hidden-table-info">
                        
            <tbody>
            <?php
                $vid=$_GET['view'];
                $VID = base64_decode(urldecode($vid));
                $result=$conn->prepare("SELECT * from reports where ReportId =$VID");
                $result->bind_result($vid, $userid, $fullname, $datetime, $sector, $subject, $body, $filename, $downloads, $size);
                $result->store_result();
                $res=$result->execute();
                while ($result->fetch()):
            ?>
            <tr>
                <th>No.</th>
                <td><?php  echo $vid;?></td>
            </tr>
            <tr>
                <th>Created by</th>
                <td><?php  echo $fullname;?></td>
            </tr>
            <tr>
                <th>Created At</th>
                <td><?php
                    $datetime = new DateTime($datetime); 
                    echo $datetime->format("d-m-Y h:i:s"); ?>
                </td></td>
            </tr>
            <tr>
                <th>Subject</th>
                <td><?php  echo $subject;?></td>
            </tr>
            <tr>
                <th>Body</th>
                <td><?php  echo $body;?></td>
            </tr>
            <tr>
                <th>File Name</th>
                <td><a style="color:blue;" href="report.php?file_report_id=<?php echo urlencode(base64_encode($vid))?>"><?php echo $filename?></td>
            </tr>
            <tr>
                <th>Download</th>
                <td><?php  echo $downloads;?></td>
            </tr>
            <tr>
                <th>Size</th>
                <td><?php echo $size/1000 . "KB";?></td>
            </tr>
        <?php endwhile; ?>    
        </tbody>
        </table>
        <?php
            if($filename!=="") {
                $image=$filename;
                $img="uploads/".$image;
                echo "<img style='vertical-align: middle; max-height:100%; max-width:100%; ' src= '$img'>";
            }
        ?>
        </div>
    </div>
</div> 

<?php endif; ?>    
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>