<?php
$conn = new mysqli('localhost', 'root', '', 'swap');
require_once('/xampp/htdocs/swap/reports/file_upload_functions.php'); 

function forgery_check(){ //check if form is in the same domain
    if(!isset($_SERVER['HTTP_REFERER'])){
        return false;
    }else{
        $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        $server_host = $_SERVER['HTTP_HOST'];
        return ($referer_host == $server_host) ? true :false ;
    }
}

if(forgery_check()){
    if (isset($_POST['insert'])){ //if UPDATE DATA button on HTML, activate insert php
            $UserId	= $_SESSION['userid'];
            $name = $_SESSION['fullname'];
            $Sector = $_SESSION['jobposition'];
            $Subject = strip_tags($_POST['subject']);
            $Body = strip_tags($_POST['body']);
            if($Subject=="") {
                $_SESSION['message'] = "Provide a Subject";    
                $_SESSION['msg_type'] = "danger";
            } else if($Body=="") {
                $_SESSION['message'] = "Provide a Description for the Report";    
                $_SESSION['msg_type'] = "danger";
            } else if ($_FILES['file']['name']!==""){
                upload_file();
            }
            else{
                $sql =$conn->prepare("INSERT INTO reports(`UserId`, `FullName`, `Sector`, `Subject`, `Body`) VALUES (?, ?, ?, ?, ?)")or die($sql->error);
                print_r($sql);
                $sql->bind_param('issss',$UserId,$name,$Sector,$Subject,$Body); //bind parameters
                //'sssssss' is used to specify the number of permeters definded
                $cre=$sql->execute();
                if($cre)
                {
                    $_SESSION['message'] = "Report Created Successfully!";
                    $_SESSION['msg_type'] = "success";
                    header("location: report.php");
                    //echo '<script type="text/JavaScript"> alert("I am an alert box!");</script>';
                }
                else
                {
                    $_SESSION['message'] = "Failed to create Report!";
                    $_SESSION['msg_type'] = "danger";
                }
            }
  
    }
    
    if(isset($_GET['file_report_id'])){
        $id=$_GET['file_report_id'];
        $rid = base64_decode(urldecode($id));
        $sql="SELECT * FROM reports WHERE ReportId=?";
        $stmt = $conn->prepare($sql); 
        $stmt->bind_param("i", $rid);
        $stmt->execute();
        $result = $stmt->get_result(); // get the mysqli result
        $file = $result->fetch_assoc(); // fetch data   
        $filename= basename($file['Filename']);
        $filepath = '/xampp/htdocs/swap/reports/uploads/'.$filename;
        $newCount=$file['Downloads'] + 1;            

            $updateQuery = "UPDATE reports SET Downloads=? WHERE ReportId=?";
            $stmt = $conn->prepare($updateQuery); 
            $stmt->bind_param("ii",$newCount,$rid);
            //Execute Prepared Statment
            $stmt->execute();
        if (!empty($file['Filename']) && file_exists($filepath)){
            // // header you want before downloading
            header('Content-Description: File Transfer');
            // //filename concatinated to file type using basename cmd
            header('Content-type: application/octet-stream');
            header('Content-Disposition: attachment; filename='.basename($filename));
            header("Pragma: public");
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Content-Length:'.filesize($filepath));
            //concatinate fullname of file this will lead file from our directory to download
            //Update Downloads Tracking on database
            ob_clean();
            flush();
            readfile($filepath);
            exit();
          


        }
    }

    $ReportId = 0;
    $UserId = 0;
    $FullName = "";
    $Sector = "";
    $Subject = "";
    $Body = "";
    $fileNewName = "";
    $fileSize = 0;
    $downloads = 0;

    if(isset($_GET['edit'])){
        $ReportId = $_GET['edit'];
        $rid = base64_decode(urldecode($ReportId));
        $edit = $conn->prepare("SELECT * FROM `reports` WHERE ReportId=$rid");
        $edit->bind_result($ReportId, $UserId, $FullName,$DateTime, $Sector, $Subject, $Body, $fileNewName,$downloads,$fileSize);
        $edit->store_result();
        $edit->execute();
        $edit->fetch();
    }
    if (isset($_POST['Update'])){
        $ReportId = $_POST['ReportId'];
        $rid = base64_decode(urldecode($ReportId));
        $Edited_Subject = strip_tags($_POST['Edited-Subject']);
        $Edited_Body = strip_tags($_POST['Edited-Body']);
        if($Edited_Subject=="") {
            $_SESSION['message'] = "Provide a Subject";    
            $_SESSION['msg_type'] = "danger";
        }else if($Edited_Body=="") {
            $_SESSION['message'] = "Provide a Description for the Report";    
            $_SESSION['msg_type'] = "danger";
        }elseif($_FILES['Edited-File']['name']!=="") {
            $file = $_FILES['Edited-File']['name'];
            print_r($file);
            edit_file();
            exit();
        }else{
            $conn = new mysqli('localhost', 'root', '', 'swap');
            $sql =$conn->prepare("UPDATE reports SET `Subject`=?, `Body`=? WHERE `ReportId`=?")or die($sql->error);
            $sql->bind_param('ssi',$Edited_Subject,$Edited_Body,$rid);                     
            //bind parameters
            $cre=$sql->execute();
            if($cre){
                $_SESSION['message'] = "Report Updated Successfully!";
                $_SESSION['msg_type'] = "success";
                header("location: report.php");
            }else
            {
                $_SESSION['message'] = "Failed to create Report!";
                $_SESSION['msg_type'] = "danger";
            }
        }
    }
    
    if (isset($_GET['delete'])){
        $ReportId=$_GET['delete'];
        $rid = base64_decode(urldecode($ReportId));
        $query=$conn->prepare("DELETE FROM `reports` WHERE ReportId=?") or die($query->error);;
        $query->bind_param('i',$rid); //bind parameters
        $del=$query->execute();
        if($del){   
            $_SESSION['message'] = "Successfully Deleted User";
            $_SESSION['msg_type'] = "success";
            header("location: report.php");
        }else{
            $_SESSION['message'] = "Failed to Delete User";
            $_SESSION['msg_type'] = "danger";
        }
    }
}else{
    exit();
}

?>

