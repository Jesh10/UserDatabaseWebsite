<?php
    session_start();
    session_regenerate_id();
    $conn = mysqli_connect("localhost","root","","swap") or die(mysqli_error($conn));
?>
<?php if($_SESSION["admin"]==""): ?>
    <?php header("location: loginform.php")?>
<?php else:?>

<!DOCTYPE html>
<html>
<head>
    <title>TP AMC - Reports</title>
    <?php 
        if($_SESSION["admin"] == "Yes"){
            require "/xampp/htdocs/swap/head&foot/header(admin).php";
        }else{
            require "/xampp/htdocs/swap/head&foot/header(user).php";
        }
    ?>
    <?php require_once "report_process.php"?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
    <a href="report.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
    <form action ="report_edit.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="ReportId" value="<?php echo urlencode(base64_encode($rid)); ?> ">
        <div class="signup-form">
            <h2>Edit Report</h2>
            <p class="hint-text">Strictly accessible by members of TP-AMC only</p>
            <input type="hidden" name="UserId" disabled class="form-control" style="position: relative; left: 30px; height: 50px; font-size: 20px" value="<?php echo $UserId; ?>">

            <div class="form-group">
                <input type="text" disabled class="form-control" id="fullname" name="fullname" value="<?php echo $FullName; ?>">
            </div>

            <div class="form-group">
                <input type="text" disabled class="form-control" id="sector" name="sector" value="<?php echo $Sector; ?>">
            </div>
                
            <div class="form-group">
                <input type="text" class="form-control" name="Edited-Subject" placeholder="Subject" required="true" value="<?php echo $Subject; ?>">
            </div>
                
            <div class="form-group">
                <textarea class="form-control" name="Edited-Body" placeholder="Enter Report Details" required="true" value=""><?php echo $Body; ?></textarea>
            </div>

            <div class="form-group">
                <input type="file" name="Edited-File" placeholder="Enter Report Attachment here" style="color: #969fa4;">
                <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $maxfilesize; ?>" >
            </div>

            <div class="form-group">
                <input type="text" disabled class="form-control" value="<?php echo $fileNewName; ?>">
            </div>

            <div class="form-group">
                <input type="text" disabled class="form-control" name="Edited-FileSize" value="<?php echo $fileSize; ?>">
            </div>
             
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="Update">Submit</button>
            </div>

        </div>
    </form>

</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>