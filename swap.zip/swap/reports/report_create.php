<html>
<?php 
    session_start();
    session_regenerate_id();?>
<?php if($_SESSION['admin'] == ""): ?>
    <?php header("location: /loginform.php")?>
<?php else:?>
<head>
    <title>TP AMC - Reports</title>
    <?php 
        if($_SESSION["admin"] == "Yes"){
            require "/xampp/htdocs/swap/head&foot/header(admin).php";
        }else{
            require "/xampp/htdocs/swap/head&foot/header(user).php";
        }
    ?>
    <?php require "/xampp/htdocs/swap/reports/report_process.php";?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
<a href="report.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<!-- Insert Report Form -->
<form action ="report_create.php" method="POST" enctype="multipart/form-data">
        <div class="signup-form">
            <h2>New Report</h2>
            <p class="hint-text">Strictly accessible by members of TP-AMC only</p>
            <input type="hidden" name="UserId" disabled class="form-control" value="<?php echo $_SESSION['userid']; ?>">

            <div class="form-group">
                <input type="text" disabled class="form-control" id="fullname" name="fullname" value="<?php echo $_SESSION['fullname']?>">
            </div>
                
            <div class="form-group">
                <input type="text" disabled class="form-control" id="sector" name="sector" value="<?php echo $_SESSION['jobposition']?>">    	
            </div>
                
            <div class="form-group">
                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject">
            </div>
                
            <div class="form-group">
                <textarea class="form-control" id="body" name="body" placeholder="Enter Report Information" required="true"></textarea>
            </div>    

            <div class="form-group">
                <input type="file" name="file" placeholder="Enter Report Attachment here" style="color: #969fa4;">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="insert" id="insert">Submit</button>
            </div>
        </div>
    </form>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>
<?php endif; ?>    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>