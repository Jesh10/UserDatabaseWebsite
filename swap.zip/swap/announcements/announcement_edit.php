<html>
<?php 
    session_start();
    session_regenerate_id();
    if($_SESSION['admin'] == "Yes"):
?>
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<head>
<title>TP AMC - Announcement</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
    <?php require "/xampp/htdocs/swap/announcements/announcement_process.php"?>
    <?php if (isset($_SESSION['message'])): ?>    
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
            <?php 
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
    <?php endif ?>

<body>
<a href="announcement.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<form action ="announcement_edit.php" method="POST">
        <div class="signup-form">
            <input type="hidden" name="AnnouncementId" value="<?php echo urlencode(base64_encode($aid)) ?>">
            <input type="hidden" name="UserId" disabled class="form-control" value="<?php echo $UserId; ?>">
            <h2>Edit Announcement</h2>
            <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>

            <div class="form-group">
                <input type="text" name="FullName" disabled class="form-control" value="<?php echo $fullname; ?>">
            </div>

            <div class="form-group">
                <input type="text" name="Sector" disabled class="form-control" value="<?php echo $sector; ?>">
            </div>
                
            <div class="form-group">
                <input type="text" name="Subject" class="form-control" placeholder="Subject" value="<?php echo $subject; ?>">
            </div>
                
            <div class="form-group">
                <input type="text" name="Body" class="form-control" placeholder="Enter Announcement Information" value="<?php echo $body; ?>">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="update">Submit</button>
            </div>
        </div>
    </form>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: /swap/home(user).php")?>
<?php else:?>
    <?php header("location: /swap/loginform.php")?>
<?php endif; ?>
</html>