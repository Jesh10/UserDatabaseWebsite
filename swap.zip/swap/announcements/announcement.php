<html>
<?php
session_start();
if (isset($_SESSION["fullname"])) :
    $con = new mysqli('localhost', 'root', '', 'swap');
    $result = $con->prepare("SELECT * FROM announcements") or die($con->error);
    $result->bind_result($aid, $uid, $fname, $dt, $sector, $subject, $body);
    $result->store_result();
    $result->execute();
?>

    <head>
        <title>TP AMC - Announcement</title>
        <?php
        if ($_SESSION["admin"] == "Yes") {
            require "/xampp/htdocs/swap/head&foot/header(admin).php";
        } else {
            require "/xampp/htdocs/swap/head&foot/header(user).php";
        }
        ?>
        <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="/swap/css/announcement.css">
        <link rel="stylesheet" href="/swap/css/default.css" />
        <link rel="stylesheet" href="/swap/css/footer.css" />
    </head>

    <body style="background-color: #F8F8F8;">
        <?php if (isset($_SESSION['message'])) : ?>
            <div class="alert alert-<?= $_SESSION['msg_type'] ?>">
                <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
                ?>
            </div>
        <?php endif ?>
        <div class="container-fluid">
            <h2 style="margin-top:20px; margin-left:65px">Announcements For <b><?php echo $_SESSION["jobposition"] ?></b></h2>
            <?php if ($_SESSION["admin"] == "Yes") : ?>
                <div class="createbtn">
                    <a href="announcement_insert.php" type="button" class="btn btn-secondary"><i style="position: relative; top: 5px; right: 5px;" class="material-icons">&#xE147;</i><span>Create New Announcement</span></a>
                </div>
            <?php endif; ?>
            <?php while ($result->fetch()) : ?>
                <?php if ($sector == $_SESSION["jobposition"]) : ?>
                    <ul class="announcementList">
                        <div class="positioning">
                            <div class="card border-secondary" style="min-height: 30%;">
                                <h4 class="item">
                                    <?php echo $subject; ?>
                                </h4>
                                <p class="details"><?php echo $body; ?></p>
                                <div class="announcementDesign">
                                    <p>
                                        <span>Posted by: <?php echo $fname . '<br>'; ?></span>
                                        <span>Posted to: <?php echo $sector . '<br>'; ?></span>
                                        <span>Posted on: <?php
                                            $dt = new DateTime($dt); 
                                            echo $dt->format("d-m-Y H:i:s"); 
                                        ?></span>
                                    </p>
                                    <?php if ($_SESSION["admin"] == "Yes") : ?>
                                        <a href="announcement_edit.php?edit=<?php echo urlencode(base64_encode($aid)); ?>" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons" style="color: #FFC107;">&#xE254;</i></a>
                                        <a href="announcement_process.php?delete=<?php echo urlencode(base64_encode($aid)) ?>" class="delete" title="Delete" data-toggle="tooltip" onclick="return confirm('Confirm to delete?');"><i class="material-icons" style="color: #E34724;">&#xE872;</i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </ul>

                <?php endif; ?>
            <?php endwhile; ?>
        </div>
    </body>
    <?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
<?php else : ?>
    <?php header("location: loginform.php"); ?>
<?php endif; ?>

</html>