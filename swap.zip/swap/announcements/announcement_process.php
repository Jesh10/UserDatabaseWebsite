<?php

$con = new mysqli('localhost', 'root', '', 'swap');

function forgery_check(){ //check if form is in the same domain
    if(!isset($_SERVER['HTTP_REFERER'])){
        return false;
    }else{
        $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        $server_host = $_SERVER['HTTP_HOST'];
        return ($referer_host == $server_host) ? true :false ;
    }
}

if(forgery_check()){
    if (isset($_POST['save'])) {
        $UserId = $_SESSION['userid'];
        $fullname = $_SESSION['fullname'];
        $sector = $_SESSION['jobposition'];
        $subject = strip_tags($_POST['Subject']);
        $body = strip_tags($_POST['Body']);

        if($subject=="") {
            $_SESSION['message'] = "Provide a Subject";    
            $_SESSION['msg_type'] = "danger";
        } else if($body=="") {
            $_SESSION['message'] = "Provide a Description for the Announcement";    
            $_SESSION['msg_type'] = "danger";
        }else{
            $result1 = $con->prepare("INSERT INTO announcements(UserId, FullName, Sector, Subject, Body) VALUES (?, ?, ?, ?, ?)");
            $result1->bind_param('issss', $UserId,$fullname, $sector, $subject, $body);
            if ($result1->execute()) {
                $_SESSION['message'] = "Successfully Created Announcement";
                $_SESSION['msg_type'] = "success";
                header("location: /swap/announcements/announcement.php"); //redirect the user back to the announcement page after adding / deleting
            }else {
                $_SESSION['message'] = "Announcement Invalid!";
                $_SESSION['msg_type'] = "danger";
            }
        }
    }

    $AnnouncementId = 0;
    $UserId = '';
    $fullname = '';
    $sector = '';
    $subject = '';
    $body = '';

    if (isset($_GET['edit'])) {
        $AnnouncementId = $_GET['edit'];
        $anid = base64_decode(urldecode($AnnouncementId));
        $result2 = $con->prepare("SELECT * FROM announcements WHERE AnnouncementId='$anid'") or die(mysqli_connect_errno());
        $result2->bind_result($aid, $UserId, $fullname, $datetime, $sector, $subject, $body);
        $result2->store_result();
        $result2->execute();
        $result2->fetch();
    }
    if (isset($_POST['update'])){
        $announcementid = $_POST['AnnouncementId'];
        $Anid = base64_decode(urldecode($announcementid));
        $Subject = strip_tags($_POST['Subject']);
        $Body = strip_tags($_POST['Body']);
        if($Subject=="") {
            $_SESSION['message'] = "Provide a Subject";    
            $_SESSION['msg_type'] = "danger";
        }else if($Body=="") {
            $_SESSION['message'] = "Provide a Description for the Maintenance Schedule";    
            $_SESSION['msg_type'] = "danger";
        }else{
            $result3 = $con->prepare("UPDATE announcements SET Subject=?, Body=? WHERE AnnouncementId=?") or die($con->error);
            $result3->bind_param('ssi',$Subject,$Body,$Anid);
            if($result3->execute()){
                $_SESSION['message'] = "Announcement Updated!";
                $_SESSION['msg_type'] = "success";
                header("location: /swap/announcements/announcement.php");
            }else{
                $_SESSION['message'] = "Announcement Invalid!";
                $_SESSION['msg_type'] = "danger";
            }
        }         
    }

    if (isset($_GET['delete'])) {
        $AnnouncementId = $_GET['delete'];
        $Did = base64_decode(urldecode($AnnouncementId));
        $result4 = $con->prepare("DELETE FROM announcements WHERE AnnouncementId=?") or die(mysqli_connect_errno());
        $result4->bind_param('s', $Did);
        if ($result4->execute()) {
            $_SESSION['message'] = "Successfully Deleted Announcement";
            $_SESSION['msg_type'] = "success";
            header("Refresh:0; url=/swap/announcements/announcement.php");
        }else{
            $_SESSION['message'] = "Failed to Delete Announcement";
            $_SESSION['msg_type'] = "danger";
        }
    }
}
?>
