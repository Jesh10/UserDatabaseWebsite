<?php
    $conn = new mysqli('localhost', 'root', '', 'swap');
    require_once('/xampp/htdocs/swap/authen/profile_upload_functions.php');
    function forgery_check(){ //check if form is in the same domain
        if(!isset($_SERVER['HTTP_REFERER'])){
            return false;
        }else{
            $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            $server_host = $_SERVER['HTTP_HOST'];
            return ($referer_host == $server_host) ? true :false ;
        }
    }

    if(forgery_check()){  
        if (isset($_POST['insert_user'])){
            $userid = null;
            $registernum = strip_tags($_POST['registernum']);
            $fullname = strip_tags($_POST['fullname']);
            $pass = strip_tags($_POST['password']);
            $confirmpassword = strip_tags($_POST['confirmpassword']);
            $dob = strip_tags($_POST['dob']);
            $gender = strip_tags($_POST['gender']);
            $nric = strip_tags($_POST['nric']);
            $email = strip_tags($_POST['email']);
            $jobposition = strip_tags($_SESSION['jobposition']);
            $admin = 'No';
            if($registernum=="") {
                $_SESSION['message'] = "Provide a Register Number";    
                $_SESSION['msg_type'] = "danger";
            }else if($registernum== 0) {
                $_SESSION['message'] = "Register Number cannot be 0";    
                $_SESSION['msg_type'] = "danger"; 
            }else if($fullname=="") {
                $_SESSION['message'] = "Provide Employee's Fullname";    
                $_SESSION['msg_type'] = "danger";
            } else if($pass=="") {
                $_SESSION['message'] = "Provide a Passwowrd";  
                $_SESSION['msg_type'] = "danger";
            } else if(strlen($pass) < 6){
                $_SESSION['message'] = "Password must be atleast 6 characters"; 
                $_SESSION['msg_type'] = "danger";
            } else if ($confirmpassword != $pass) {
                $_SESSION['message'] = "Passwords do not match";
                $_SESSION['msg_type'] = "danger";
            } else if($dob=="") {
                $_SESSION['message'] = "Provide a valid Date of Birth";
                $_SESSION['msg_type'] = "danger";
            } else if($nric=="" or strlen($nric) < 9) {
                $_SESSION['message'] = "Provide a valid NRIC";
                $_SESSION['msg_type'] = "danger";
            } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = 'Please enter a valid Email Address';
                $_SESSION['msg_type'] = "danger";
            } else if($jobposition =="") {
                $_SESSION['message'] = "Provide a valid Job Position";
                $_SESSION['msg_type'] = "danger";
            } elseif($_FILES['file']['name']!=="") {
                $file = $_FILES['file']['name'];
                upload_user();
                exit();
            }else{
                $password = password_hash($pass, PASSWORD_DEFAULT);
                $file ="61fc0af80428f0.92522518.png";
                $query= $conn->prepare("INSERT INTO users VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $query->bind_param("iisssssssss", $userid,$registernum,$fullname,$password,$dob,$gender,$nric,$email,$jobposition,$admin,$file)or die($sql->error);
                $res = $query->execute();
                if ($res){
                    $_SESSION['message'] = "Registration Successful";
                    $_SESSION['msg_type'] = "success";
                    header("location: employees.php");
                }else{
                    $_SESSION['message'] = "Registration Failed";
                    $_SESSION['msg_type'] = "danger";
                }
            }
        }

        if (isset($_POST['insert_admin'])){
            $userid = null;
            $registernum = 0;
            $fullname = strip_tags($_POST['fullname']);
            $pass = strip_tags($_POST['password']);
            $confirmpassword = strip_tags($_POST['confirmpassword']);
            $dob = strip_tags($_POST['dob']);
            $gender = strip_tags($_POST['gender']);
            $nric = strip_tags($_POST['nric']);
            $email = strip_tags($_POST['email']);
            $jobposition = strip_tags($_SESSION['jobposition']);
            $admin = 'Yes';

            if($registernum != 0) {
                $_SESSION['message'] = "Register Number cannot be changed";    
                $_SESSION['msg_type'] = "danger";
            } else if($fullname=="") {
                $_SESSION['message'] = "Provide Employee's Fullname";    
                $_SESSION['msg_type'] = "danger";
            }else if($pass=="") {
                $_SESSION['message'] = "Provide a Passwowrd";  
                $_SESSION['msg_type'] = "danger";
            } else if(strlen($pass) < 6){
                $_SESSION['message'] = "Password must be atleast 6 characters"; 
                $_SESSION['msg_type'] = "danger";
            } else if ($confirmpassword != $pass) {
                $_SESSION['message'] = "Passwords do not match";
                $_SESSION['msg_type'] = "danger";
            } else if($dob=="") {
                $_SESSION['message'] = "Provide a valid Date of Birth";
                $_SESSION['msg_type'] = "danger";
            } else if($nric=="" or strlen($nric) < 9) {
                $_SESSION['message'] = "Provide a valid NRIC";
                $_SESSION['msg_type'] = "danger";
            } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = 'Please enter a valid Email Address';
                $_SESSION['msg_type'] = "danger";
            } else if($jobposition =="") {
                $_SESSION['message'] = "Provide a valid Job Position";
                $_SESSION['msg_type'] = "danger";
            } else {
                $password = password_hash($pass, PASSWORD_DEFAULT);
                $file =" ";
                $query= $conn->prepare("INSERT INTO users VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $query->bind_param("iisssssssss", $userid,$registernum,$fullname,$password,$dob,$gender,$nric,$email,$jobposition,$admin,$file)or die($sql->error);
                $res = $query->execute();
                if ($res){
                    $_SESSION['message'] = "Registration Successful";
                    $_SESSION['msg_type'] = "success";
                    header("location: employees.php");
                }else{
                    $_SESSION['message'] = "Registration Failed";
                    $_SESSION['msg_type'] = "danger";
                }
            }
        }

        $userid = 0;
        $fullname = "";
        $dob = "";
        $gender = "";
        $nric = "";
        $email = "";
        $jobposition = "";

        if (isset($_GET['edit'])){
            $uid = $_GET['edit'];
            $userid = base64_decode(urldecode($uid));
            $result = $conn->prepare("SELECT UserId, RegisterNum, FullName, DateofBirth, Gender, NRIC, Email, JobPosition FROM users WHERE UserId=$userid");
            $result->bind_result($id, $registernum, $fullname, $dob, $gender, $nric, $email, $jobposition);
            $result->store_result();
            $res=$result->execute();
            $row = $result->fetch();
        }

        if (isset($_POST['update'])){
            $uid = $_POST['userid'];
            $userid = base64_decode(urldecode($uid));
            $registernum = strip_tags($_POST['registernum']);
            $fullname = strip_tags($_POST['fullname']);
            $dob = strip_tags($_POST['dob']);
            $gender = strip_tags($_POST['gender']);
            $nric = strip_tags($_POST['nric']);
            $email = strip_tags($_POST['email']);
            $jobposition = strip_tags($_POST['jobposition']);
            
            if($registernum=="") {
                $_SESSION['message'] = "Provide a Register Number";    
                $_SESSION['msg_type'] = "danger";
            }else if($registernum== 0) {
                $_SESSION['message'] = "Register Number cannot be 0";    
                $_SESSION['msg_type'] = "danger"; 
            }else if($fullname=="") {
                $_SESSION['message'] = "Provide Employee's Fullname";    
                $_SESSION['msg_type'] = "danger";
            }else if($dob=="") {
                $_SESSION['message'] = "Provide a valid Date of Birth";
                $_SESSION['msg_type'] = "danger";
            } else if($nric=="" or strlen($nric) < 9) {
                $_SESSION['message'] = "Provide a valid NRIC";
                $_SESSION['msg_type'] = "danger";
            } else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['message'] = 'Please enter a valid Email Address';
                $_SESSION['msg_type'] = "danger";
            } else if($jobposition =="") {
                $_SESSION['message'] = "Provide a valid Job Position";
                $_SESSION['msg_type'] = "danger";
            } elseif($_FILES['Edited-File']['name']!=="") {
                $file = $_FILES['Edited-File']['name'];
                edit_file();
                exit();
            }else {
                $update = $conn->prepare("UPDATE users SET RegisterNum=?, FullName=?, DateOfBirth=?, Gender=?, NRIC=?, Email=?, JobPosition=? WHERE UserId=?") or die($conn->error);
                $update->bind_param("issssssi", $registernum, $fullname, $dob, $gender, $nric, $email, $jobposition, $userid);
                $res=$update->execute();
                if($res){
                    $_SESSION['message'] = "Update Successful";
                    $_SESSION['msg_type'] = "success";
                    header("location: employees.php");
                }else{
                    $_SESSION['message'] = "Update Failed";
                    $_SESSION['msg_type'] = "danger";
                }
            }
        }
        if (isset($_GET['delete'])){
            $uid = $_GET['delete'];
            $userid = base64_decode(urldecode($uid));
            $query=$conn->prepare("DELETE from users WHERE UserId=?") or die($conn->error());
            $query->bind_param('i',$userid); //bind parameters
            $del=$query->execute();
            if ($del){
                $_SESSION['message'] = "Successfully Deleted User";
                $_SESSION['msg_type'] = "success";
                header("location: employees.php");
            }else{
                $_SESSION['message'] = "Failed to Delete User";
                $_SESSION['msg_type'] = "danger";
            }
        }
    }
?>