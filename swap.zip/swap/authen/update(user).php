<html lang="en">
    <?php
        session_start();
        session_regenerate_id();
        if($_SESSION['admin'] == "Yes"): 
        require "/xampp/htdocs/swap/head&foot/header(admin).php";
    ?>
    <head>
        <title>TP AMC - Employees</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="/swap/css/basic.css">
        <link rel="stylesheet" href="/swap/css/footer.css">
    </head>
    <body>
    <?php require_once "admin_process.php"?>
    <?php if (isset($_SESSION['message'])): ?>    
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
            <?php 
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
    <?php endif ?>
    <form action ="update(user).php" method="POST"  enctype="multipart/form-data">
        <div class="signup-form">
            <h2>Update <?php echo $fullname; ?> Details</h2>
            <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>
            <input type="hidden" name="userid" value="<?php echo urlencode(base64_encode($id)) ?> ">
            <div class="form-group">
                <input type="file" name="Edited-File" placeholder="Enter Report Attachment here" style="color: #969fa4;">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="Username" name="fullname" placeholder="Full Name" value="<?php echo $fullname; ?>">
            </div>
            <div class="form-group">
            <div class="row">
                <div class="col"><input type="text" class="form-control" id="RegisterNum" name="registernum" value="<?php echo $registernum; ?>"></div>
                <div class="col"><input type="text" class="form-control" id="jobposition" name="jobposition" value="<?php echo $jobposition ?>"></div>
            </div>        	
            </div>
            <div class="form-group">
                <input type="date" class="form-control" id="DateofBirth" name="dob" value="<?php echo $dob; ?>">
            </div>
                
            <div class="form-group">
                <select id="Gender" class="form-control" name="gender" value="<?php echo $gender; ?>">
                    <option>Male</option>
                    <option>Female</option>
                </select>
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="nric" name="nric" placeholder="NRIC" value="<?php echo $nric; ?>">
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="email" name="email" placeholder="Email Address" value="<?php echo $email; ?>">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="update">Submit</button>
            </div>
        </div>
    </form>
<body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
<html>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: home(user).php")?>
<?php else:?>
    <?php header("location: loginform.php")?>
<?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>
<script>
    //to bring in other HTML on the fly into this page
    w3.includeHTML();
</script>