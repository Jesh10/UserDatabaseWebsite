<?php 
    session_start();
    session_regenerate_id();
    if($_SESSION['admin'] == "Yes"):
?>
<html lang="en">
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<link rel="stylesheet" href="/swap/css/footer.css">
    <head>
    <title>TP AMC - Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    </head>
    <body>
    <a href="employees.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
    <div class="signup-form">
            <h2 style="colour: #636363; margin-top:100px; font-size:55px">Who are you registering for?</h2>
            <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>
            <div class="form-group">
                <div class="row" style="margin-right: 20px">
                    <div class="col"><a href="register(user).php" class="btn btn-primary btn-lg" style="text-decoration: none; padding: 0.7rem 5rem; font-size:20px; margin-left: -30px;">Employee</a></div>
                    <div class="col"><a href="securitykey.php" class="btn btn-warning btn-lg" style="text-decoration: none; padding: 0.7rem 5rem; margin-left: 30px; font-size:20px;">Manager</a></div>
                </div>        	
            </div>    
        </div>  
    </body>
    <?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: home(user).php")?>
<?php else:?>
    <?php header("location: loginform.php")?>
<?php endif; ?>