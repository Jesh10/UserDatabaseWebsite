<html lang="en">
    <?php 
        session_start();
        session_regenerate_id();
        if($_SESSION['admin'] == "Yes"):
        require "/xampp/htdocs/swap/head&foot/header(admin).php";
    ?>
    <?php 
        $inactive = 60;
        if (isset($_SESSION["timeout"])) {
            // calculate the session's "time to live"
            $sessionTTL = time() - $_SESSION["timeout"];
            if ($sessionTTL > $inactive) {
                header("location: register.php");
            }
        }
        $_SESSION["timeout"]=time();
        
    ?>

<script>
    function countDown(secs,elem) {

        var element = document.getElementById(elem);
        element.innerHTML = "Session Timeout in: "+secs+" seconds";

        if(secs < 1) {
            clearTimeout(timer);
            window.location.href = "register.php";
        }

        secs--;
        var timer = setTimeout('countDown('+secs+',"'+elem+'")',1000);
    }
</script>

<div id="status" style="font-size: 15px; color: black; text-align: right;"></div>
<script>countDown(60,"status");</script>  -->
<head>
    <title>TP AMC - Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css"></head>
    <link rel="stylesheet" href="/swap/css/footer.css">
<body>
    <?php require_once "admin_process.php"?>
    <?php if (isset($_SESSION['message'])): ?>    
        <div class="alert alert-<?= $_SESSION['msg_type']?>">
        <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        ?>
    </div>
    <?php endif ?>
    <form action ="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>"method="POST" enctype="multipart/form-data">
        <div class="signup-form">
            <h2>Registration for Employee</h2>
            <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>
            <div class="form-group">
                <input type="file" name="file" placeholder="Enter Report Attachment here" style="color: #969fa4;">
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="Username" name="fullname" placeholder="Full Name">
            </div>
                
            <div class="form-group">
            <div class="row">
                <div class="col"><input type="text" class="form-control" id="RegisterNum" name="registernum" placeholder="Register No."></div>
                <div class="col"><input type="text" disabled class="form-control" id="jobposition" name="jobposition" value="<?php echo $_SESSION["jobposition"] ?>"></div>
            </div>        	
            </div>
                
            <div class="form-group">
                <input type="date" class="form-control" id="DateofBirth" name="dob">
            </div>
                
            <div class="form-group">
                <select id="Gender" class="form-control" name="gender">
                    <option>Male</option>
                    <option>Female</option>
                </select>
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="nric" name="nric" placeholder="NRIC">
            </div>

            <div class="form-group">
                <input type="text" class="form-control" id="email" name="email" placeholder="Email Address">
            </div>

            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>

            <div class="form-group">
                <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Confirm Password">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="insert_user">Submit</button>
            </div>
        </div>
    </form>
<body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: home(user).php")?>
<?php else:?>
    <?php header("location: loginform.php")?>
<?php endif; ?>
<html>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>
<script>
    //to bring in other HTML on the fly into this page
    w3.includeHTML();
</script>

