<?php 
    $conn = new mysqli('localhost', 'root', '', 'swap');
    $check = false;
    $result = $conn->query("SELECT Security_key FROM security_keys WHERE KeyId=1 ");
    $row = $result->fetch_assoc();
    $dbkey = $row['Security_key'];

    if (isset($_POST['check'])){
        $userkey = $_POST['userkey'];
        if (password_verify($userkey, $dbkey)){
            $check = true;
            $_SESSION['message'] = "Security Key Matched";
            $_SESSION['msg_type'] = "success";
        }
        else if ($userkey=""){
            $_SESSION['message'] = "Invalid Security Key";
            $_SESSION['msg_type'] = "danger";
        }
        else{
            $_SESSION['message'] = "Invalid Security Key";
            $_SESSION['msg_type'] = "danger";
        }
    }
?>