<?php 
    session_start();
    if($_SESSION['admin'] == "Yes"):
    $conn = new mysqli('localhost', 'root', '', 'swap');
    $result = $conn->prepare("SELECT UserId, RegisterNum, FullName, DateofBirth, Gender, NRIC, Email, JobPosition, Admin, Filename FROM users ORDER BY RegisterNum ");
    $result->bind_result($id, $rnum, $fname, $dob, $gender, $nric, $email, $jp, $ad, $filename);
    $result->store_result();
    $res=$result->execute();
?>

<!DOCTYPE html>
<html lang="en">
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>TP AMC - Employees</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="/swap/css/default.css">
<link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-<?=$_SESSION['msg_type']?>">
            <?php 
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            ?>
        </div>
    <?php endif ?>
    <div class="container-xl">
        <div class="table-responsive">
            <div class="table-wrapper">
                <div class="table-title">
                    <div class="row">
                    <div class="col-sm-6">
                        <h2 style="margin-top:10px;">Employees Details for <b><?php echo $_SESSION["jobposition"] ?></b></h2>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Index No.</th>
                        <th>Profile Picture</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>NRIC</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>   
                <thead>
                <tbody>
        <?php while ($result->fetch()): ?>
            <?php if($jp == $_SESSION["jobposition"]):?>
                <tr>
                <?php if($ad == 'No'):?>
                    <td><?php echo $rnum?></td>
                    <td> 
                    <?php
                        $image=$filename;
                        $img="profile/".$image;
                        echo "<img style='vertical-align: middle; width: 50px; height: 50px; border-radius:30% ' src= '$img'>"; ?>
                    </td>
                    <td><?php echo $fname?></td>
                    <td><?php
                        $dob = new DateTime($dob); 
                        echo $dob->format("d-m-Y"); ?></td>
                    <td><?php echo $gender?></td>
                    <td><?php echo $nric?></td>
                    <td><?php echo $email?></td>
                    <td>
                        <a href="update(user).php?edit=<?php echo urlencode(base64_encode($id))?>" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        <a href="admin_process.php?delete=<?php echo urlencode(base64_encode($id))?>" class="delete" title="Delete" data-toggle="tooltip" onclick="return confirm('Are you sure you want to delete this user?');"><i class="material-icons">&#xE872;</i></a>
                    </td>
                <?php endif;?>
                </tr>
            <?php endif;?>
        <?php endwhile; ?>
            </tbody>
            </table>
            <?php if($_SESSION["admin"] == "No"):?>
            <?php elseif($_SESSION["admin"] == "Yes"):?>
                <a href="register.php" type="button" class="btn btn-secondary btn-lg btn-block"><i style="position: relative; top: 5px; right: 5px;" class="material-icons">&#xE147;</i><span>Register a New Employee</span></a>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php"?>
</html>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: home(user).php");?>
<?php else:?>
    <?php header("location: loginform.php");?>
<?php endif; ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>
<script>
    //to bring in other HTML on the fly into this page
    w3.includeHTML();
</script>