<?php 
    session_start();
    session_regenerate_id();
    if($_SESSION['admin'] == "Yes"):
    $conn = mysqli_connect("localhost","root","","swap") or die(mysqli_error($conn));
 ?>
<!doctype html>
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<html lang="en">
  <head>
  <title>TP AMC - Attendance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
  </head>
<body>
<?php require_once "/xampp/htdocs/swap/attendance/attendance_process.php"?>
<a href="attendance_log_user.php?id=<?php echo urlencode(base64_encode($UserId))?> & employee=<?php echo urlencode(base64_encode($FullName))?>" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<form action ="attendance_log_user_edit.php" method="POST">
    <div class="signup-form">
        <input type="hidden" name="UserId" value="<?php echo $uid ?> ">
        <input type="hidden" name="AttendanceId" value="<?php echo urlencode(base64_encode($AttendanceId)) ?> ">
        <h2>Edit <?php echo $FullName; ?> Record</h2>
        <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>

            <div class="form-group" >
                <input type="text" class="form-control" id="FullName" name="FullName" readonly="readonly" value="<?php echo $FullName; ?>">
            </div>

            <div class="form-group" >
                <input type="text" class="form-control" id="Sector" name="Sector" readonly="readonly" value="<?php echo $Sector; ?>">
            </div>

            <div class="form-check">
                <input class="form-check-input" type="radio" id="presentRadio" name="EditedAttendance" value="Present" checked="checked">
                <label class="form-check-label" for="Present" style="color: black;">Present</label>
            </div>
                
            <div class="form-check">
                <input class="form-check-input" type="radio" id="absentRadio" name="EditedAttendance" value="Absent">
                <label class="form-check-label" for="Present" style="color: black;">Absent</label>
            </div>
            <br>
            <div class="form-group">
                <textarea class="form-control" id="Body" name="EditedBody" placeholder="Remarks if any"><?php echo $Body; ?></textarea>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="Update" value="Update Record">Submit</button>
            </div>
    </div>
</form>

<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: /swap/home(user).php")?>
<?php else:?>
    <?php header("location: /swap/loginform.php")?>
<?php endif; ?>

</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>
