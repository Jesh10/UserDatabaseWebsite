<?php 
    session_start();
    if($_SESSION['admin'] == "Yes"):
 ?> 
    <?php
        $conn = new mysqli('localhost', 'root', '', 'swap');
        $Uid = $_GET['id'];
        $UserId = base64_decode(urldecode($Uid));
        $result = $conn->prepare("SELECT DISTINCT AttendanceId, UserId, RegisterNum, FullName, Sector, Date, Attendance, Body FROM attendance WHERE UserId=?") or die($conn->error);
        $result->bind_param("i", $UserId);
        $result->execute();
        $result->store_result();
        $result->bind_result($AttendanceId, $UserId, $RegisterNum, $FullName, $Sector, $Date, $Attendance, $Body);
        if(isset($_GET['employee'])){
            $Eid = $_GET['employee'];
            $Employee = base64_decode(urldecode($Eid));
        }
        
    ?> 
<html>
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php" ?>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>TP AMC - Attendance</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="/swap/css/default.css">
<link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
<?php require_once "/xampp/htdocs/swap/attendance/attendance_process.php"?>
<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-<?=$_SESSION['msg_type']?>">
        <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        ?>
    </div>
<?php endif ?>

<div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2>Attendance List of <b><?php echo $Employee?></b></h2>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
				        <th>Date</th>
                        <th>Present/Absent</th>
                        <th>Remarks</th>
                        <th>Action</th>
                    </tr>
                </thead>
        <tbody>	
        <?php while ($result->fetch()): ?>
            <?php if($Sector == $_SESSION["jobposition"]):?>
                <tr>
                    <td>
                    <?php
                        $Date = new DateTime($Date); 
                        echo $Date->format("d-m-Y"); 
                    ?>
                    </td>
                    <td><?php echo $Attendance?></td>
                    <td><?php echo $Body?></td>
                    <td>
                        <a href="attendance_log_user_edit.php?edit=<?php echo urlencode(base64_encode($AttendanceId))?> & user=<?php echo urlencode(base64_encode($UserId))?> & employee=<?php echo urlencode(base64_encode($FullName))?>" class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        <a href="attendance_log_user.php?delete=<?php echo urlencode(base64_encode($AttendanceId))?> & user=<?php echo urlencode(base64_encode($UserId))?> & employee=<?php echo urlencode(base64_encode($FullName))?>" class="delete" title="Delete" data-toggle="tooltip" onclick="return confirm('Confirm to delete?');"><i class="material-icons">&#xE872;</i></a>
                    </td>
                </tr>
            <?php endif;?>
        <?php endwhile; ?>
        </tbody>  
    </table>
    <a onclick="location.href='attendance_list.php'" style="color:white;" type="button" class="btn btn-secondary btn-lg btn-block"><i style="position: relative; top: 5px; right: 5px; color:black;"></i><span>Return to Attendance List</span></a>
</div>

<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: /swap/home(user).php")?>
<?php else:?>
    <?php header("location: /swap/loginform.php")?>
<?php endif; ?>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://www.w3schools.com/lib/w3.js"></script>
<script>
    //to bring in other HTML on the fly into this page
    w3.includeHTML();
</script>

