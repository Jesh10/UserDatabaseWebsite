<?php 
    session_start();
    session_regenerate_id();
    if($_SESSION['admin'] == "Yes"):
 ?>
<!doctype html>
<?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
<html lang="en">
<head>
    <title>TP AMC - Attendance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="/swap/css/basic.css">
    <link rel="stylesheet" href="/swap/css/footer.css">
</head>
<body>
<?php require_once "/xampp/htdocs/swap/attendance/attendance_process.php"?>
<?php 
    $conn = new mysqli('localhost', 'root', '', 'swap');
    
    $UserId = "";
    $RegisterNum = "";
    $FullName = "";
    $Sector = "";

    if (isset($_GET['new'])){
        $Uid= $_GET['new'];
        $UserId = base64_decode(urldecode($Uid));
        $result = $conn->prepare("SELECT UserId, RegisterNum, FullName, JobPosition FROM users WHERE UserId=$UserId");
        $result->bind_result($UserId, $RegisterNum, $FullName, $Sector);
        $result->store_result();
        $res=$result->execute();
        $row = $result->fetch();
    }
?>
<?php if (isset($_SESSION['message'])): ?>    
    <div class="alert alert-<?= $_SESSION['msg_type']?>">
    <?php 
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    ?>
</div>
<?php endif ?>
<a href="attendance_list.php" class="btn btn-secondary" style="margin-top: 10px; margin-left: 10px; padding: 5px 48px;">Return</a>
<form action ="attendance_new.php" method="POST">
    <div class="signup-form">
        <input type="hidden" name="id" value="<?php echo urlencode(base64_encode($UserId)); ?>"><br>
        <h2>New Attendance Record for <?php echo $FullName; ?></h2>
        <p class="hint-text">Strictly accessible by Admins of TP-AMC only</p>

            <div class="form-group" >
                <input type="text" class="form-control" id="FullName" name="FullName" readonly="readonly" value="<?php echo $FullName; ?>">
            </div>

            <div class="form-group">
            <div class="row">
                <div class="col"><input type="text" class="form-control" id="registernum" name="RegisterNum" readonly="readonly" value="<?php echo $RegisterNum; ?>"></div>
                <div class="col"><input type="text" class="form-control" id="Sector" name="Sector" readonly="readonly" value="<?php echo $Sector; ?>"></div>
            </div>        	
            </div>


            <div class="form-check">
                <input class="form-check-input" type="radio" id="presentRadio" name="Attendance" value="Present" checked="checked">
                <label class="form-check-label" for="Present" style="color: black;">Present</label>
            </div>
                
            <div class="form-check">
                <input class="form-check-input" type="radio" id="absentRadio" name="Attendance" value="Absent">
                <label class="form-check-label" for="Present" style="color: black;">Absent</label>
            </div>
            <br>
            <div class="form-group">
                <textarea class="form-control" id="Body" name="Body" placeholder="Remarks if any"></textarea>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-success btn-lg btn-block" name="insert" value="Add Record">Submit</button>
            </div>
    </div>
</form>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>
<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: /swap/home(user).php")?>
<?php else:?>
    <?php header("location: /swap/loginform.php")?>
<?php endif; ?>
