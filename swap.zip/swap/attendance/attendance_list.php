<?php 
    session_start();
    if($_SESSION['admin'] == "Yes"):
    $conn = new mysqli('localhost', 'root', '', 'swap');
    $result = $conn->prepare("SELECT UserId, RegisterNum, FullName, JobPosition, Admin FROM users ORDER BY RegisterNum");
    $result->bind_result($UserId, $RegisterNum, $FullName, $Sector, $Admin);
    $result->store_result();
    $result->execute();
?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>TP AMC - Attendance</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="/swap/css/default.css">
<link rel="stylesheet" href="/swap/css/footer.css">
</head>
<header> 
    <?php require "/xampp/htdocs/swap/head&foot/header(admin).php"?>
</header>
<body>
<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-<?=$_SESSION['msg_type']?>">
        <?php 
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        ?>
    </div>
<?php endif ?>

    <div class="container-xl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
                        <h2>Attendance List for <b><?php echo $_SESSION["jobposition"]?></b></h2>
                    </div>
                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Index No.</th>
                        <th>Full Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
        <tbody>	
        <?php while ($result->fetch()): ?>
            <?php if($Sector == $_SESSION["jobposition"]):?>
                <tr>
                <?php if($Admin == 'No'):?>
                    <td><?php echo $RegisterNum?></td>
                    <td><?php echo $FullName?></td>
                    <td>
                        <a href="attendance_new.php?new=<?php echo urlencode(base64_encode($UserId))?>"><i class="material-icons">&#xE147;</i></a>
                        <a href="attendance_log_user.php?id=<?php echo urlencode(base64_encode($UserId))?> & employee=<?php echo urlencode(base64_encode($FullName))?>" class="view" title="View" data-toggle="tooltip"><i class="material-icons">&#xE417;</i></a>
                    </td>
                <?php endif;?>
                </tr>
            <?php endif;?>
        <?php endwhile; ?>
        </tbody>  
    </table>
    <a onclick="location.href='attendance_logs.php'" style="color:white;" type="button" class="btn btn-secondary btn-lg btn-block"><i style="position: relative; top: 5px; right: 5px; color:black;"></i><span>View All Today's Attendance Logs</span></a>
</div>

<?php elseif($_SESSION['admin'] == "No"):?>
    <?php header("location: /swap/home(user).php")?>
<?php else:?>
    <?php header("location: /swap/loginform.php")?>
<?php endif; ?>
</body>
<?php require "/xampp/htdocs/swap/head&foot/footer.php" ?>
</html>
