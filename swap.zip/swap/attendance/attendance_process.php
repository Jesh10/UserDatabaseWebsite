<?php
    $conn = new mysqli('localhost', 'root', '', 'swap');
    
    $UserId = 0;
    $RegisterNum = '';
    $FullName = '';
    $Sector = '';

    if (isset($_POST['insert'])){
        $UID=$_POST['id'];
        $id = base64_decode(urldecode($UID));
        $Rnum=$_POST['RegisterNum'];
        $Fname=$_POST['FullName'];
        $Sect=$_POST['Sector'];
        $Body=strip_tags($_POST['Body']);
        $Attendance=$_POST['Attendance'];
        $insert= $conn->prepare("INSERT INTO attendance(UserId, RegisterNum, FullName, Sector, Attendance, Body) VALUES(?, ?, ?, ?, ?, ?)");
        $insert->bind_param("iissss", $id, $Rnum, $Fname, $Sect, $Attendance, $Body);
        if($insert->execute()){
            $_SESSION['message'] = "Attendance Successfully Recorded!";
            $_SESSION['msg_type'] = "success";
            header("location: /swap/attendance/attendance_logs.php");
        }
        else{
            $_SESSION['message'] = "Record Invalid!";
            $_SESSION['msg_type'] = "danger";
            die($conn->error);
        }
    }

    $AttendanceId = 0;
    $UserId = 0;
    $FullName = "";
    $Sector = "";
    $Attendance = "";
    $Body = "";
    $EditedAttendance = "";
    $EditedBody = "";

    //retrieves info from particular row
    if(isset($_GET['edit'])){
        $AttendanceId = $_GET['edit'];
        $Aid = base64_decode(urldecode($AttendanceId));
        $result = $conn->prepare("SELECT * FROM `attendance` WHERE AttendanceId=$Aid");
        $result->bind_result($AttendanceId, $UserId, $RegisterNum, $FullName, $Sector, $Datetime, $Attendance, $Body);
        $result->store_result();
        $result->execute();
        $result->fetch();
    }

    if(isset($_GET['user'])){
        $uid = $_GET['user'];
    }
  
    if (isset($_POST['Update'])){
        $AttendanceId = $_POST['AttendanceId'];
        $Aid = base64_decode(urldecode($AttendanceId));
        $UserId = $_POST['UserId'];
        $FullName =  $_POST['FullName'];
        $Sector = $_POST['Sector'];
        $EditedAttendance = $_POST['EditedAttendance'];
        $EditedBody = strip_tags($_POST['EditedBody']);
        $sql= $conn->prepare("UPDATE attendance SET FullName=?, Sector=?, Attendance=?, Body=? WHERE AttendanceId=?") or die($conn->error);
        $sql->bind_param('ssssi',$FullName,$Sector,$EditedAttendance,$EditedBody,$Aid); //bind parameters
            //'sssssss' is used to specify the number of perimeters definded
        if($sql->execute()){
            $_SESSION['message'] = "Attendance Successfully Updated!";
            $_SESSION['msg_type'] = "success";
            header("location: /swap/attendance/attendance_log_user.php?id=" . $UserId . "&employee=" . urlencode(base64_encode($FullName)));
        }
        else{
            $_SESSION['message'] = "Failed to Update Attendance";
            $_SESSION['msg_type'] = "danger";
        }
    }

    if (isset($_GET['delete'])){
        $AttendanceId=$_GET['delete'];
        $AId = base64_decode(urldecode($AttendanceId));
        $query=$conn->prepare("DELETE FROM `attendance` WHERE AttendanceId=?");
        $query->bind_param('i',$AId); //bind parameters
        if($query->execute()){
            if(isset($_GET['user'])){
                $UserId=$_GET['user'];
                if(isset($_GET['employee'])){
                    $FullName=$_GET['employee'];
                    header("Refresh:0; url=/swap/attendance/attendance_log_user.php?id=" . $UserId . "&employee=" . $FullName);
                    $_SESSION['message'] = "Attendance Successfully Deleted!";
                    $_SESSION['msg_type'] = "success";
                }
            }
        }else{
            die($query->error);
            $_SESSION['message'] = "Failed to Delete Attendance";
            $_SESSION['msg_type'] = "danger";
        }
    }
?>

